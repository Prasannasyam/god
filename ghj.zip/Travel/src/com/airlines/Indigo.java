package com.airlines;

public class Indigo {
	
	public Indigo() {
		
		// TODO Auto-generated constructor stub
	}
	public Indigo(int noofseats, int noofseats1, int crew, int timeofflight, int timeofflight1, String dayofflight,
			String dayofflight1) {
		
		this.noofseats = noofseats;
		this.noofseats1 = noofseats1;
		this.crew = crew;
		this.timeofflight = timeofflight;
		this.timeofflight1 = timeofflight1;
		this.dayofflight = dayofflight;
		this.dayofflight1 = dayofflight1;
	}
    int noofseats=100;
	int noofseats1=150;
	int crew=5;
	int timeofflight=12;
	int timeofflight1=9;
	String dayofflight="Tuesday";
	String dayofflight1="Friday";
	

	public int getNoofseats() {
		return noofseats;
	}
	public void setNoofseats(int noofseats) {
		this.noofseats = noofseats;
	}
	public int getNoofseats1() {
		return noofseats1;
	}
	public void setNoofseats1(int noofseats1) {
		this.noofseats1 = noofseats1;
	}
	public int getCrew() {
		return crew;
	}
	public void setCrew(int crew) {
		this.crew = crew;
	}
	public int getTimeofflight() {
		return timeofflight;
	}
	public void setTimeofflight(int timeofflight) {
		this.timeofflight = timeofflight;
	}
	public int getTimeofflight1() {
		return timeofflight1;
	}
	public void setTimeofflight1(int timeofflight1) {
		this.timeofflight1 = timeofflight1;
	}
	public String getDayofflight() {
		return dayofflight;
	}
	public void setDayofflight(String dayofflight) {
		this.dayofflight = dayofflight;
	}
	public String getDayofflight1() {
		return dayofflight1;
	}
	public void setDayofflight1(String dayofflight1) {
		this.dayofflight1 = dayofflight1;
	}
	public int totaltimeofindigo(int a,int b) {
		return a+b;
	}
	public int distanceofindigo(int s,int t) {
		return s*t;
		
	}
	

}
