package com.airlines;

public class Kingfisher extends Indigo {
	
	public static void main(String arg[]) {
		
		Indigo indigo = new Kingfisher();
		
		System.out.println(indigo.getNoofseats());
		System.out.println(indigo.getCrew());
		System.out.println(indigo.getDayofflight1());
		System.out.println(indigo.getTimeofflight1());
		System.out.println(indigo.totaltimeofindigo(11,12));
		System.out.println(indigo.distanceofindigo(30,3));
		
		
		
	}
	
      
}
	
