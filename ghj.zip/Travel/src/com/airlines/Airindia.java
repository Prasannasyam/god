package com.airlines;

public class Airindia extends Indigo {
	
	public static void main(String arg[]) {
		
		Indigo indigo = new Airindia();
		
		
		System.out.println(indigo.getNoofseats());
		System.out.println(indigo.getCrew());
		System.out.println(indigo.getTimeofflight());
		System.out.println(indigo.getDayofflight());
		System.out.println(indigo.totaltimeofindigo(10,8));
		System.out.println(indigo.distanceofindigo(45,5));
		
		
	}

}
